const state = { current: 0, completed: new Set(JSON.parse(localStorage.getItem("redes-completed") || "[]")), query: "" };
const nav = document.getElementById("topicNav"), grid = document.getElementById("topicGrid");
const welcome = document.getElementById("welcome"), stats = document.getElementById("statsGrid"), catalog = document.getElementById("catalog"), detail = document.getElementById("detailView");
const $ = id => document.getElementById(id);
function esc(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function answerHTML(text){
  const lines=text.split("\n").map(x=>x.trim()).filter(Boolean); let out="", listType="";
  for(const line of lines){
    const bullet=line.startsWith("•"), numbered=/^\d+\./.test(line);
    if(bullet||numbered){
      const type=bullet?"ul":"ol";
      if(listType!==type){if(listType)out+=`</${listType}>`;out+=`<${type}>`;listType=type;}
      const content=esc(line.replace(/^•\s*/,"").replace(/^\d+\.\s*/,""));
      out+=`<li>${content}</li>`;
    }else{
      if(listType){out+=`</${listType}>`;listType="";}
      out+=`<p>${esc(line)}</p>`;
    }
  }
  if(listType)out+=`</${listType}>`;
  return out;
}
function renderNav(){
  nav.innerHTML=TOPICS.map(t=>`<button class="nav-item ${state.current===t.id?"active":""}" data-id="${t.id}"><span class="nav-num">${String(t.id).padStart(2,"0")}</span><span>${esc(t.title)}</span>${state.completed.has(t.id)?'<span class="nav-check">✓</span>':""}</button>`).join("");
  nav.querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>openTopic(+b.dataset.id)));
}
function renderGrid(){
  const filtered=TOPICS.filter(t=>(t.title+" "+t.question+" "+t.answer).toLowerCase().includes(state.query.toLowerCase()));
  grid.innerHTML=filtered.map(t=>`<button class="topic-card ${state.completed.has(t.id)?"done":""}" data-id="${t.id}"><div class="card-top"><span class="number">MÓDULO ${String(t.id).padStart(2,"0")}</span><span class="status">${state.completed.has(t.id)?"✓ REVISADO":"↗"}</span></div><h3>${esc(t.title)}</h3><span class="open-label">Ver consigna y respuesta →</span></button>`).join("");
  grid.querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>openTopic(+b.dataset.id)));
  $("resultCount").textContent=`${filtered.length} ${filtered.length===1?"MÓDULO":"MÓDULOS"}`;
  $("emptyState").hidden=filtered.length!==0;
}
function updateProgress(){
  const n=state.completed.size;
  $("progressText").textContent=`${n} / 28`; $("progressBar").style.width=(n/28*100)+"%"; $("completedStat").textContent=n;
}
function showCatalog(){
  welcome.hidden=false;stats.hidden=false;catalog.hidden=false;detail.hidden=true;
  $("crumbTitle").textContent="INICIO";state.current=0;renderNav();window.scrollTo({top:0,behavior:"smooth"});
}
function openTopic(id){
  const t=TOPICS.find(x=>x.id===id);if(!t)return;state.current=id;
  welcome.hidden=true;stats.hidden=true;catalog.hidden=true;detail.hidden=false;
  $("crumbTitle").textContent=t.title.toUpperCase();$("detailNumber").textContent=`MÓDULO ${String(id).padStart(2,"0")}`;
  $("detailTitle").textContent=t.title;$("detailQuestion").textContent=t.question;
  $("detailAnswer").innerHTML=answerHTML(t.answer);$("diagramTitle").textContent=t.diagramTitle;
  $("detailImage").src=t.image;$("detailImage").alt=t.diagramTitle;
  $("markButton").classList.toggle("is-done",state.completed.has(id));
  $("markButton").textContent=state.completed.has(id)?"✓ Revisado":"✓ Marcar como revisado";
  $("prevButton").disabled=id===1;$("nextButton").disabled=id===28;
  $("prevButton").style.opacity=id===1?".4":"1";$("nextButton").style.opacity=id===28?".4":"1";
  renderNav();window.scrollTo({top:0,behavior:"smooth"});
  document.getElementById("sidebar").classList.remove("open");
}
$("startButton").addEventListener("click",()=>openTopic(1));
$("backButton").addEventListener("click",showCatalog);
$("prevButton").addEventListener("click",()=>openTopic(state.current-1));
$("nextButton").addEventListener("click",()=>openTopic(state.current+1));
$("markButton").addEventListener("click",()=>{
  if(state.completed.has(state.current))state.completed.delete(state.current);else state.completed.add(state.current);
  localStorage.setItem("redes-completed",JSON.stringify([...state.completed]));updateProgress();renderNav();
  $("markButton").classList.toggle("is-done",state.completed.has(state.current));
  $("markButton").textContent=state.completed.has(state.current)?"✓ Revisado":"✓ Marcar como revisado";
});
$("searchInput").addEventListener("input",e=>{state.query=e.target.value;renderGrid();if(state.query){welcome.hidden=true;stats.hidden=true;catalog.hidden=false;detail.hidden=true;}else if(!detail.hidden){/* keep current detail open */}else{welcome.hidden=false;stats.hidden=false;}});
$("themeToggle").addEventListener("click",()=>{document.body.classList.toggle("theme-dark");localStorage.setItem("redes-theme",document.body.classList.contains("theme-dark")?"dark":"light");});
if(localStorage.getItem("redes-theme")==="dark")document.body.classList.add("theme-dark");
$("menuToggle").addEventListener("click",()=>document.getElementById("sidebar").classList.toggle("open"));
document.addEventListener("keydown",e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==="k"){e.preventDefault();$("searchInput").focus();}if(e.key==="Escape"){$("imageModal").hidden=true;document.getElementById("sidebar").classList.remove("open");}});
$("imageOpen").addEventListener("click",()=>{$("modalImage").src=$("detailImage").src;$("imageModal").hidden=false;});
$("modalClose").addEventListener("click",()=>$("imageModal").hidden=true);
$("imageModal").addEventListener("click",e=>{if(e.target===$("imageModal"))$("imageModal").hidden=true;});
renderNav();renderGrid();updateProgress();
