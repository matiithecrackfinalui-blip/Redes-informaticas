const TOPICS = [
  {
    "id": 1,
    "title": "Criterios para clasificar las redes informáticas",
    "question": "Indique y describa distintos criterios para clasificar las redes informáticas.",
    "answer": "Las redes informáticas se pueden clasificar según diversos criterios principales:\n• Cobertura geográfica: LAN, MAN, WAN e Internet.\n• Topología: en estrella, bus, anillo, malla y árbol.\n• Relación funcional: Cliente-Servidor y Punto a Punto (Peer-to-Peer / P2P).\n• Medio de transmisión: guiadas (cable de par trenzado, fibra óptica) y no guiadas (Wi-Fi, radiofrecuencia, microondas).\n• Propiedad / Acceso: redes públicas, privadas, Intranet y Extranet.",
    "diagramTitle": "Mapa conceptual: criterios de clasificación de redes informáticas",
    "image": "assets/diagramas/diagrama-01.png"
  },
  {
    "id": 2,
    "title": "Clasificación geográfica: LAN e Internet",
    "question": "¿Por qué decimos que en la actualidad la clasificación de las redes bajo el criterio geográfico implica solamente dos tipos de redes: LAN e Internet?",
    "answer": "Con el avance tecnológico y la globalización de las telecomunicaciones, las fronteras intermedias (como MAN o WAN tradicionales) se han unificado tecnológicamente. En la práctica actual, los usuarios operan dentro de su red local (LAN) doméstica o corporativa, o se conectan directamente a la red global descentralizada (Internet) para acceder a todos los recursos y servicios del mundo.",
    "diagramTitle": "Diagrama de interconexión: red local (LAN) a Internet global",
    "image": "assets/diagramas/diagrama-02.png"
  },
  {
    "id": 3,
    "title": "Intranet y Extranet",
    "question": "Defina y dé ejemplos de redes Intranet y Extranet.",
    "answer": "• Intranet: red privada y restringida de una organización para uso exclusivo de sus empleados y colaboradores internos.\nEjemplo: el portal interno de un banco donde sus empleados gestionan legajos y consultas administrativas.\n• Extranet: extensión privada de una Intranet que permite acceso limitado y seguro a usuarios externos autorizados.\nEjemplo: la plataforma donde un proveedor consulta el estado de sus facturas o inventario en tiempo real.",
    "diagramTitle": "Esquema de niveles de acceso: Intranet, Extranet e Internet",
    "image": "assets/diagramas/diagrama-03.png"
  },
  {
    "id": 4,
    "title": "Tecnologías de acceso a Internet",
    "question": "¿Cuáles son y qué características presentan los tipos de tecnología utilizados para dar acceso a Internet? Incluya una imagen representativa.",
    "answer": "• Fibra Óptica (FTTH): transmite datos mediante pulsos de luz. Ofrece las mayores velocidades (simétricas) y muy baja latencia.\n• DSL / Cablemódems: utilizan líneas telefónicas o redes de televisión por cable (coaxial).\n• Redes Móviles (4G / 5G): acceso inalámbrico de alta velocidad para dispositivos móviles.\n• Satelital: cobertura global en zonas rurales o de difícil acceso geográfico.",
    "diagramTitle": "Diagrama de tecnologías de acceso a Internet (fibra, celular, satelital)",
    "image": "assets/diagramas/diagrama-04.png"
  },
  {
    "id": 5,
    "title": "Acceso a Internet en empresas",
    "question": "¿Qué tecnologías utilizan las empresas para acceder a Internet? Busque información actualizada.",
    "answer": "Las empresas utilizan soluciones de alta confiabilidad y ancho de banda garantizado, como:\n• Enlaces dedicados de Fibra Óptica (Internet Simétrico).\n• Conexiones SD-WAN (Software-Defined WAN) para gestión inteligente del tráfico.\n• Enlaces redundantes de respaldo mediante tecnología Satelital de baja órbita (LEO) o redes inalámbricas 5G corporativas.",
    "diagramTitle": "Arquitectura de conectividad corporativa y redundancia",
    "image": "assets/diagramas/diagrama-05.png"
  },
  {
    "id": 6,
    "title": "Redes convergentes",
    "question": "¿Qué caracteriza a las redes convergentes? Describa sus factores e incluya una imagen representativa.",
    "answer": "Una red convergente es aquella capaz de consolidar y transportar múltiples tipos de servicios (datos, voz e imágenes/video) sobre una misma infraestructura física y un protocolo común (TCP/IP). Esto elimina la necesidad de contar con cableados independientes para teléfonos, televisión y computadoras, optimizando costos y administración.",
    "diagramTitle": "Integración de datos, voz y video sobre red convergente IP",
    "image": "assets/diagramas/diagrama-06.png"
  },
  {
    "id": 7,
    "title": "Redes del futuro",
    "question": "En pocas palabras, caracterice las redes que se planificarán para el futuro. Incluya una imagen representativa.",
    "answer": "Las redes del futuro se caracterizan por ser hiperconectadas, automatizadas y altamente adaptativas. Destacan el uso de Inteligencia Artificial para la autogestión y optimización del tráfico, virtualización completa (SDN/NFV), ultra baja latencia con 6G y soporte masivo para el Internet de las Cosas (IoT).",
    "diagramTitle": "Visión de las redes del futuro: IA, 6G e IoT",
    "image": "assets/diagramas/diagrama-07.png"
  },
  {
    "id": 8,
    "title": "Arquitectura de una red (IIR)",
    "question": "Indique y describa las cuatro características básicas que debe responder la arquitectura de una red.",
    "answer": "1. Tolerancia a fallos: capacidad de mantener la continuidad del servicio redirigiendo el tráfico si falla un componente.\n2. Escalabilidad: habilidad de expandirse para admitir nuevos usuarios y dispositivos sin degradar el rendimiento.\n3. Calidad de Servicio (QoS): priorización del tráfico crítico (como voz o video en vivo) ante congestiones.\n4. Seguridad: protección contra accesos no autorizados y garantía de confidencialidad e integridad.",
    "diagramTitle": "Los cuatro pilares de la arquitectura de red",
    "image": "assets/diagramas/diagrama-08.png"
  },
  {
    "id": 9,
    "title": "Conmutación por paquetes",
    "question": "¿Cuál es la mayor ventaja de las redes conmutadas por paquetes frente a las redes conmutadas por circuitos?",
    "answer": "La mayor ventaja es el aprovechamiento eficiente de los recursos del canal de comunicación. En la conmutación por paquetes, la línea no se reserva de forma exclusiva; los datos se dividen en paquetes independientes que comparten dinámicamente las rutas, permitiendo que miles de usuarios transmitan simultáneamente.",
    "diagramTitle": "Transmisión por paquetes y multiplexación",
    "image": "assets/diagramas/diagrama-09.png"
  },
  {
    "id": 10,
    "title": "Conmutación por circuitos",
    "question": "¿Qué ventaja presentan las redes conmutadas por circuitos frente a las redes conmutadas por paquetes?",
    "answer": "Su ventaja principal es que ofrece un canal dedicado y exclusivo durante toda la sesión. Esto garantiza un ancho de banda constante, velocidad uniforme y una latencia fija sin variaciones ni retardos por enrutamiento de paquetes (ideal para telefonía tradicional en tiempo real).",
    "diagramTitle": "Canal exclusivo dedicado en conmutación por circuitos",
    "image": "assets/diagramas/diagrama-10.png"
  },
  {
    "id": 11,
    "title": "Internet como red jerárquica",
    "question": "¿Por qué decimos que Internet es una red jerárquica? Analice con sus compañeros cuáles serían sus niveles de jerarquía desde el punto de vista geográfico.",
    "answer": "Es jerárquica porque se estructura en niveles de proveedores de servicio (ISPs):\n• Tier 1 (Nivel Internacional/Global): dorsales submarinas e intercontinentales de alta velocidad.\n• Tier 2 (Nivel Nacional/Regional): proveedores con cobertura en un país o región que interconectan redes.\n• Tier 3 (Nivel Local): proveedores locales que entregan conectividad directa a usuarios finales y empresas.",
    "diagramTitle": "Estructura jerárquica de ISPs (Tier 1, Tier 2, Tier 3)",
    "image": "assets/diagramas/diagrama-11.png"
  },
  {
    "id": 12,
    "title": "Ejemplo de QoS",
    "question": "Dé un ejemplo en el que se aplique un criterio de calidad de servicio (QoS).",
    "answer": "En un hogar u oficina donde se realiza una videollamada o llamada VoIP (como Zoom o Teams) mientras se descarga un archivo grande. El router con QoS prioriza los paquetes de voz y video en tiempo real para evitar distorsiones o cortes, asignándoles prioridad sobre la descarga en segundo plano.",
    "diagramTitle": "Colas de priorización QoS (voz/video vs. datos)",
    "image": "assets/diagramas/diagrama-12.png"
  },
  {
    "id": 13,
    "title": "Seguridad de una red",
    "question": "¿Cuáles son los requisitos principales que deben alcanzarse para cumplir los objetivos de seguridad de una red?",
    "answer": "Los objetivos fundamentales conforman la llamada “Tríada CID”:\n• Confidencialidad: garantizar que la información sea accesible únicamente por usuarios autorizados.\n• Integridad: asegurar que los datos no hayan sido alterados o modificados sin autorización.\n• Disponibilidad: garantizar el acceso confiable y oportuno a los datos y recursos cuando se requiera.",
    "diagramTitle": "Tríada CID: confidencialidad, integridad y disponibilidad",
    "image": "assets/diagramas/diagrama-13.png"
  },
  {
    "id": 14,
    "title": "Tendencias de Internet",
    "question": "Mencione y caracterice algunas tendencias hacia las que se inclina la red de redes (Internet).",
    "answer": "• Internet de las Cosas (IoT): conexión masiva de electrodomésticos y dispositivos industriales.\n• Computación en la Nube y Edge Computing: procesamiento descentralizado más cerca del usuario.\n• Adopción masiva de IPv6: para reemplazar la saturada reserva de direcciones IPv4.\n• Ciberseguridad avanzada basada en IA y arquitecturas Zero Trust.",
    "diagramTitle": "Mapa conceptual de tendencias tecnológicas",
    "image": "assets/diagramas/diagrama-14.png"
  },
  {
    "id": 15,
    "title": "Internet e internet",
    "question": "¿Qué diferencia hay entre Internet e internet?",
    "answer": "• internet (con minúscula): término genérico que hace referencia a cualquier interconexión de dos o más redes de computadoras (una red de redes privada o local).\n• Internet (con mayúscula): la red mundial descentralizada e interconectada globalmente mediante el conjunto de protocolos TCP/IP, de acceso público.",
    "diagramTitle": "Comparación: “internet” (privada) vs. “Internet” (mundial)",
    "image": "assets/diagramas/diagrama-15.png"
  },
  {
    "id": 16,
    "title": "Enfoque BYOD",
    "question": "¿En qué consiste el enfoque BYOD?",
    "answer": "BYOD proviene del inglés “Bring Your Own Device” (Trae Tu Propio Dispositivo). Es una política empresarial/educativa donde los empleados o estudiantes utilizan sus propios dispositivos personales (laptops, smartphones, tablets) para conectarse a la red institucional y realizar sus tareas laborales o académicas.",
    "diagramTitle": "Integración de dispositivos personales en la red (BYOD)",
    "image": "assets/diagramas/diagrama-16.png"
  },
  {
    "id": 17,
    "title": "Internet a través de redes eléctricas",
    "question": "¿En qué consiste la tecnología de acceso a Internet a través de las redes eléctricas?",
    "answer": "Conocida como BPL (Broadband over Power Lines) o PLC (Power Line Communication), es una tecnología que transmite señales de datos de alta velocidad superponiéndolas sobre los cables de la infraestructura eléctrica existente, permitiendo llevar conexión a través de los tomacorrientes convencionales.",
    "diagramTitle": "Comunicación PLC sobre red eléctrica",
    "image": "assets/diagramas/diagrama-17.png"
  },
  {
    "id": 18,
    "title": "WISP",
    "question": "¿Qué es un WISP? ¿En qué caso utilizaría este tipo de proveedor?",
    "answer": "Un WISP (Wireless Internet Service Provider) es un Proveedor de Servicios de Internet Inalámbrico. Transmite señales de datos por radiofrecuencia a antenas receptoras. Se utiliza principalmente en zonas rurales, suburbanas o geográficamente aisladas donde el cableado o la fibra óptica no llegan.",
    "diagramTitle": "Conexión WISP: torre emisora a antena cliente",
    "image": "assets/diagramas/diagrama-18.png"
  },
  {
    "id": 19,
    "title": "Amenazas en redes Wi-Fi",
    "question": "Mencione y caracterice distintas amenazas de seguridad en redes Wi-Fi.",
    "answer": "• Interceptación / Man-in-the-Middle (MitM): atacantes capturan tráfico de datos no cifrado.\n• Puntos de acceso falsos (Rogue AP / Evil Twin): redes Wi-Fi clonadas para robar credenciales.\n• Ataques de fuerza bruta: para adivinar contraseñas de cifrado débil.\n• Infiltración por falta de aislamiento de clientes.",
    "diagramTitle": "Amenazas y vectores de ataque en Wi-Fi",
    "image": "assets/diagramas/diagrama-19.png"
  },
  {
    "id": 20,
    "title": "Protección de redes Wi-Fi",
    "question": "¿Qué medidas tomaría para disminuir o anular las amenazas mencionadas anteriormente?",
    "answer": "• Utilizar cifrado robusto actualizado (WPA3 o WPA2-Enterprise).\n• Cambiar las contraseñas predeterminadas del router / AP.\n• Ocultar el SSID o deshabilitar WPS (Wi-Fi Protected Setup).\n• Usar VPNs en redes públicas y segmentar la red mediante VLANs o redes de invitados.",
    "diagramTitle": "Capas de protección para redes Wi-Fi",
    "image": "assets/diagramas/diagrama-20.png"
  },
  {
    "id": 21,
    "title": "Beneficios de las redes",
    "question": "Complete las letras faltantes: “Las redes informáticas permiten a sus usuarios compartir r _ _ _ _ _ _ s; y estos pueden ser de dos tipos h _ _ d _ _ _ e, y i n _ _ _ m _ _ _ _ n”.",
    "answer": "Frase completa:\n“Las redes informáticas permiten a sus usuarios compartir recursos; y estos pueden ser de dos tipos hardware, e información”.",
    "diagramTitle": "Recursos compartidos: hardware e información",
    "image": "assets/diagramas/diagrama-21.png"
  },
  {
    "id": 22,
    "title": "Redes de igual a igual y cliente-servidor",
    "question": "Caracterice las infraestructuras de igual a igual (peer-to-peer) y cliente-servidor.",
    "answer": "• Cliente-Servidor: infraestructura centralizada donde un servidor dedicado administra los recursos y responde a las solicitudes de múltiples clientes.\n• Igual a igual (P2P): arquitectura descentralizada donde todos los nodos cumplen funciones tanto de cliente como de servidor, compartiendo recursos directamente entre sí.",
    "diagramTitle": "Comparativa: cliente-servidor vs. peer-to-peer (P2P)",
    "image": "assets/diagramas/diagrama-22.png"
  },
  {
    "id": 23,
    "title": "Nombre de un cliente en la red",
    "question": "¿Cómo se suele denominar a un cliente en una red?",
    "answer": "En la jerga de redes, a un dispositivo cliente conectado a la red se le suele denominar Host, Terminal, Estación de trabajo (Workstation) o Nodo final (End device).",
    "diagramTitle": "Clientes y nodos finales en la red",
    "image": "assets/diagramas/diagrama-23.png"
  },
  {
    "id": 24,
    "title": "Cómo se distinguen los servicios en la red",
    "question": "Un host puede solicitar varios servicios a un servidor. ¿Cómo hacen el host y el servidor para distinguir la información de los distintos servicios si viaja por la red?",
    "answer": "Lo hacen mediante los Números de Puerto en la capa de transporte (TCP/UDP). Cada servicio tiene asignado un puerto específico (por ejemplo, Puerto 80/443 para navegación Web HTTP/HTTPS, Puerto 25 para Correo SMTP). La combinación de la Dirección IP y el Puerto (Socket) identifica unívocamente cada conexión.",
    "diagramTitle": "Puertos TCP/UDP e identificación de sockets",
    "image": "assets/diagramas/diagrama-24.png"
  },
  {
    "id": 25,
    "title": "Ventajas y limitaciones de P2P",
    "question": "Una infraestructura peer-to-peer (P2P) permite que una terminal actúe como cliente y servidor. ¿Qué ventajas y limitaciones presenta este tipo de red?",
    "answer": "• Ventajas: fácil configuración, bajo costo (no requiere servidores dedicados) y alta resiliencia/descentralización.\n• Limitaciones: dificultad para centralizar la seguridad y respaldos, menor rendimiento a gran escala y sobrecarga en los equipos cliente.",
    "diagramTitle": "Matriz de ventajas y limitaciones de redes P2P",
    "image": "assets/diagramas/diagrama-25.png"
  },
  {
    "id": 26,
    "title": "Componentes de la infraestructura de red",
    "question": "La infraestructura de red contiene tres categorías de componentes. ¿Cuáles son y qué función cumple cada una?",
    "answer": "1. Dispositivos finales (Hosts): origen y destino de los mensajes (PC, smartphones, impresoras).\n2. Dispositivos intermediarios: conectan los dispositivos finales y dirigen el tráfico (Routers, Switches, Firewalls).\n3. Medios de red: proporcionan el canal o soporte físico/inalámbrico por donde viajan las señales (cables de cobre, fibra óptica, aire/radio).",
    "diagramTitle": "Dispositivos finales, intermediarios y medios",
    "image": "assets/diagramas/diagrama-26.png"
  },
  {
    "id": 27,
    "title": "Diagramas y topologías",
    "question": "Defina diagrama, topología, topología física y topología lógica.",
    "answer": "• Diagrama: representación gráfica de la red mediante símbolos estándar.\n• Topología: estructura o forma en que se organizan los elementos de la red.\n• Topología Física: disposición y ubicación real de los cables y dispositivos físicos.\n• Topología Lógica: la forma en que los datos viajan a través de los medios de un punto a otro.",
    "diagramTitle": "Diferencia entre topología física y topología lógica",
    "image": "assets/diagramas/diagrama-27.png"
  },
  {
    "id": 28,
    "title": "Comparación entre LAN, WAN e Internet",
    "question": "Mediante un cuadro o mapa, caracterice las redes LAN, WAN e Internet considerando área, usuarios, servicios y responsabilidad.",
    "answer": "• LAN: área geográfica reducida (hogar/oficina). Usuarios locales. Servicios compartidos de alta velocidad. Administrada por el propietario local.\n• WAN: área amplia (ciudades/países). Múltiples organizaciones. Servicios de interconexión. Administrada por proveedores de telecomunicaciones (TELCOs).\n• Internet: cobertura global. Miles de millones de usuarios. Acceso público descentralizado a información. Coadministrada globalmente mediante estándares compartidos.",
    "diagramTitle": "Cuadro comparativo: LAN, WAN e Internet",
    "image": "assets/diagramas/diagrama-28.png"
  }
];
