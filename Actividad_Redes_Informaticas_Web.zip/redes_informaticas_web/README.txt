ACTIVIDAD INTERACTIVA - REDES INFORMÁTICAS

ARCHIVOS:
- index.html: página principal.
- styles.css: diseño visual adaptable a celulares y computadoras.
- topics.js: contenido de los 28 módulos.
- app.js: navegación, búsqueda, progreso y modo oscuro.
- assets/diagramas/: 28 diagramas originales extraídos del documento.

PARA VERLA EN TU COMPUTADORA:
1. Descomprimí el archivo ZIP.
2. Abrí la carpeta redes_informaticas_web.
3. Hacé doble clic en index.html. Se abre en tu navegador.

PARA PUBLICARLA GRATIS:
- Netlify: entrá a https://app.netlify.com/drop y arrastrá la carpeta del sitio
  (o el ZIP descomprimido) al área de publicación.
- GitHub Pages: creá un repositorio, subí el contenido de esta carpeta y activá
  Pages desde Settings > Pages.

No requiere instalar programas ni ejecutar un servidor. La tipografía puede
cargarse desde Google Fonts cuando haya conexión; el sitio funciona sin ella
con tipografías alternativas.
